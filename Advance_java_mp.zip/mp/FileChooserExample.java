import javafx.application.Application;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import java.io.File;

public class FileChooserExample extends Application {
    public static void main(String[] args) {
        launch(args); // it starts your javafx application
    }

    @Override// this annotation is used for denoting that below given function is being override(same to same) from its parent class Application
    public void start(Stage primaryStage) // this method initialises the code
    {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open File Dialog");

        // Set initial directory (optional)
        // fileChooser.setInitialDirectory(new File(System.getProperty("user.home")));

        File selectedFile = fileChooser.showOpenDialog(primaryStage); // it basically opens the opening file choosing dialog 
                                                                      // if user clicks open then it returns, if user clicks cancel it returns null
        if (selectedFile != null) {
            System.out.println("Selected File: " + selectedFile.getAbsolutePath());
        } else {
            System.out.println("No file selected.");
        }
    }
}
