import java.awt.*;
import java.io.File;
import java.io.*;

class pdf_open{

    public static void main(String args[])
    {
        try{
            File file=new File("D:\\TY-IF\\EST\\EST_info.pdf");
            if(file.exists())
            {
                Desktop.getDesktop().open(file);
            }
            else
            {
                System.out.println("Pdf file not found !");
            }
        }
        catch(IOException e)
        {
           e.printStackTrace();
        }
    }
}