import java.awt.FlowLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.*;
import java.net.*;
import javax.swing.*;

class dumy_sr{
  static JFrame f;
  static JTextField t1,t2;
  static JLabel l1,l2;
  static JButton b1;
  public static void main(String[] args) {
    try{
      f=new JFrame();
      t1=new JTextField();
      t2=new JTextField();
      l1=new JLabel("Client says:");
      l2=new JLabel("Type here:");
      b1=new JButton("send");
      f.setVisible(true);
      f.setSize(700,700);
      f.setLayout(null);
      f.add(l1);
      f.add(l2);
      f.add(t1);
      f.add(t2);
      f.add(b1);
      t1.setBounds(290, 300, 160, 30);
      t2.setBounds(290, 350, 160, 30);
      b1.setBounds(328, 400, 90, 27);// x-axis for horizontal positioning
      l1.setBounds(200, 300, 150, 30);
      l2.setBounds(205, 350, 150, 30);
     
    ServerSocket ss=new ServerSocket(1080);
    Socket s=ss.accept();
    DataInputStream di=new DataInputStream(s.getInputStream());

    // String str2=di.readUTF();
    // t1.setText(str2);
    // System.out.println(str2);
    // di.close();
   
    DataOutputStream dos=new DataOutputStream(s.getOutputStream());
    b1.addMouseListener(new MouseAdapter() {
      public void mouseClicked(MouseEvent m)
      {try{
        String str3=t2.getText();
        t2.setText("");
        dos.writeUTF(str3);
        dos.flush();
        // dos.close();
        // s.close();
        
      }
      catch(Exception e)
      {
        System.out.println(e);
      }
      }
    });

while (true) {
   String str2=di.readUTF();
    t1.setText(str2);           // for continous communication used while loop
    System.out.println(str2);
}
     

//         dos.close();
//             di.close();

// s.close();
//     ss.close();
  }
  catch(Exception e)
  {
System.out.println(e);
  }
}
}