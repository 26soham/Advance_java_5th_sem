import javax.swing.*;
import java.awt.event.*;
import java.io.*;

public class file_save{

    public static void main(String[] args) {
        JFrame frame = new JFrame("Save As Example");
        JButton saveButton = new JButton("Save As");

        saveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                JFileChooser fileChooser = new JFileChooser();


                int choice = fileChooser.showSaveDialog(null);
                if (choice == JFileChooser.APPROVE_OPTION) 
                {
                    File selectedFile = fileChooser.getSelectedFile();
                    String filePath = selectedFile.getAbsolutePath();
 
                    // Save the file at the specified path
                    try (PrintWriter writer = new PrintWriter(filePath)) {
                        writer.println("This is the content of the saved file.");
                        System.out.println("File saved successfully at: " + filePath);
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                } else {
                    System.out.println("Save operation canceled.");
                }

                
            }
        });

        frame.add(saveButton);
        frame.setSize(200, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}

