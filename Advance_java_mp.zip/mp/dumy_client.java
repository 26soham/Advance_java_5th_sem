// C:\Users\Hp\OneDrive\Desktop\spro\OSY_mp
import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.*;

class dumy_client{
    static JFrame f;
  static JTextField t1,t2;
  static JButton b1;
  static JLabel l1,l2;
  public static void main(String[] args) {
    try{
        f=new JFrame();
        t1=new JTextField();
        t2=new JTextField();
        l1=new JLabel("Server Says:");
        l2=new JLabel("Type here:");
        b1=new JButton("send");
        f.setVisible(true);
        f.setSize(700,700);
        f.setLayout(null);
        f.add(l1);
        f.add(l2);
        f.add(t1);
        f.add(t2);
        f.add(b1);
        t1.setBounds(290, 300, 160, 30);
        t2.setBounds(290, 350, 160, 30);
        b1.setBounds(328, 400, 90, 27);// x-axis for horizontal positioning
        l1.setBounds(200, 300, 150, 30);
        l2.setBounds(205, 350, 150, 30);

    Socket s=new Socket("localhost",1080);
    DataOutputStream di=new DataOutputStream(s.getOutputStream());
    
    b1.addMouseListener(new MouseAdapter() {
        public void mouseClicked(MouseEvent m)
        {   try{
            String x=t2.getText();
            t2.setText("");
            di.writeUTF(x);
            di.flush();
            // di.close();
            //  s.close();// always remember use this socket close with previous close componet don't keep him alone 
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        }
    });

    DataInputStream di2=new DataInputStream(s.getInputStream());

    while (true) {
       String str4=di2.readUTF();   // used for continous communication  used whie loop
     t1.setText(str4);
    }
    //  di2.close();
    //         di.close();

    //  s.close();
   
  }
  catch(Exception e)
  {
System.out.println(e);
  }
}
}